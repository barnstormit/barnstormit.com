# Website Build Session Summary — April 2-3, 2026

## What We Accomplished

### Website (barnstormit.com)
- **Designed the full site** using Google Stitch — created DESIGN.md and STITCH_PROMPTS.md (17 prompts across 6 rounds)
- **Built and deployed all major pages via Claude Code (Opus 4.6, Max plan):**
  - Homepage — hero (local mountain photo), 5 service cards, trust section with real headshot + bio, service area zones, contact CTA
  - Services — full categorized list including Hardware, Software, Data, Networking, Business IT, 3D Printing, Training & Education, Web & Digital, AI & Automation
  - Contact — working email form via Resend API delivering to jeff@barnstormit.com
  - Remote Support — RustDesk download links, step-by-step setup guide with redacted screenshots, copy-to-clipboard server config fields
  - 3D Printing — dedicated page with service cards, how it works section
  - About — full bio, 4-stage career timeline with photos (Buffalo, Colorado IT, Summit County hospitality, Barnstorm launch)
  - Pricing — rates and zone table
  - Blog — post index with category filters, individual post pages, markdown-based system. 5 posts (3 placeholder + 2 real)
- **Added comprehensive SEO** — meta tags, OG tags, canonical URLs, sitemap.xml, robots.txt, LocalBusiness JSON-LD schema on all pages
- **Set up email form backend** — Resend account (resend@dev.barnstormit.com), domain verified, DNS records in Porkbun, API route at app/api/contact/route.js, environment variable in Vercel
- **Brand voice updated** — "we/Barnstorm" in general copy, "Jeff" reserved for About and trust section only
- **Business hours updated** — Monday–Friday 9AM–5PM, emergency service available

### RustDesk Remote Support Server
- Set up in separate conversation on RackNerd VPS (107.175.137.52, Ubuntu 24.04)
- hbbs + hbbr running in Docker containers
- Public key: znmg4BbrRHz2X20rKw0vqNI5AVv9Dpwy8Lh6KJBNXzw=
- Client config: ID Server 107.175.137.52, Relay Server 107.175.137.52
- Tested successfully between AI Box (guest WiFi) and laptop (home WiFi)
- Created redacted screenshots for website setup guide

### SEO & Marketing Setup
- **Google Search Console** — verified, sitemap submitted
- **Bing Webmaster Tools** — verified, sitemap submitted
- **Google Business Profile** — created, services listed, photos uploaded, pending verification (up to 5 days)
- **Apple Business Connect** — attempted, phone verification failed, retry later
- **Nextdoor Business** — page created, docs uploaded, pending verification
- On-site SEO complete across all pages

### Blog Posts Written
1. "SSD vs HDD: The $100 Upgrade That Makes Your Old Laptop Feel New" — Tech Tips
2. "Tech Checklist for Short-Term Rental Hosts" — Tech Tips
3. "Why Your WiFi Is Slow in a Log Cabin" — placeholder
4. "Launching a Tech Business at 10,000 Feet" — placeholder
5. "What 3D Printing Means for Mountain Communities" — placeholder

### Development Workflow Established
- Stitch for design mockups → Claude Code for implementation
- Dev server on AI Box port 3001 (3000 used by Open WebUI)
- Preview from K8 Plus via Tailscale (100.74.36.8:3001, allowedDevOrigins configured)
- Git workflow: commit locally for checkpoints, push to deploy via Vercel
- Claude Code running Opus 4.6 on Max plan with 1M context

### Key Decisions Made
- "We/Barnstorm" language instead of "Jeff" for scalability
- Service Call Fee (not Travel Fee) for zone pricing
- Skip ads (Google, Nextdoor) for now — organic first
- Resend over Formspree for email form (growth-ready, Option 3)
- Blog posts show expertise without giving away implementation details
- RustDesk free OSS server for now, upgrade to Pro later if volume justifies branded client
- 3D printing page honest about needing client-provided files (no CAD design services yet)
- Business hours: Monday–Friday 9-5, emergency available
- Home address for Nextdoor only (neighborhood-based), PO Box for everything else

### Still To Do
- Service Area page (expanded zone detail)
- Vacation Tech Help page (STR niche)
- Set up remote.barnstormit.com DNS pointing to VPS
- Google Business Profile verification (waiting)
- Nextdoor verification (waiting)
- Apple Business Connect retry
- Facebook Business Page
- LinkedIn Company Page
- Chamber of Commerce listings (Park County, Summit County)
- Write more real blog posts (replace placeholders)
- Municipal business licenses (Breckenridge, Frisco, Dillon, Leadville, Buena Vista)
- Mobile responsiveness review across all pages

### Files Created/Updated This Session
- DESIGN.md — full design system with all pages, brand voice, 3D printing, blog, remote support
- STITCH_PROMPTS.md — 17 prompts across 6 rounds + 4 refinement prompts
- Backend_Infrastructure_Reference.md — updated with website, RustDesk, Resend, SEO details
- Blog posts: ssd-vs-hdd.md, str-tech-checklist.md
- Redacted RustDesk screenshots (5 files)
- About page photos (hero, buffalo, waterfall, summit, snowboard)
- Blog post images (wifilogcabin.jpg, tech10k.jpg, 3dprint.jpg, ssd-vs-hdd.jpg, str-checklist.jpg)
