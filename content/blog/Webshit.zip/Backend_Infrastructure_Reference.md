# Backend Infrastructure Reference
## Barnstorm Computer Services LLC — Home Lab & Business Systems

*Last updated: April 3, 2026*

---

## Network Overview

### Physical Layout

| Device | Role | Network | IP / Tailscale IP | OS |
|---|---|---|---|---|
| ASUS ZenWiFi AX (XT8) | Primary router | Main LAN | 10.0.1.1 (gateway) | ASUS firmware |
| GMKtec K8 Plus | Daily driver + GPU inference server | Main LAN (10.0.1.x) | Tailscale: 100.123.247.112 | Windows 11 Pro |
| NUCbox G3 Plus ("AI Box") | Docker host, automation hub, website dev | Guest WiFi | Tailscale: 100.74.36.8 | Windows 11 Pro |
| Raspberry Pi 4 ("dns01") | AdGuard Home + Tailscale exit node | Main LAN (10.0.1.201) | Tailscale: 100.125.241.20 | Raspberry Pi OS Lite |
| Acer Swift 14 | Mobile workstation (laptop) | Main WiFi / remote | Tailscale: 100.81.163.128 | Windows 11 Pro |
| OnePlus 13 | Mobile phone | Cellular / WiFi | Tailscale: 100.97.242.89 | Android 16 |
| GMKtec G3 Plus ("Start9") | StartOS — Bitcoin Knots, Nextcloud, Vaultwarden, etc. | Main LAN (10.0.1.225) | N/A | StartOS |
| Raspberry Pi 3 | Home Assistant (planned) | Main LAN (10.0.1.x) | N/A | TBD |
| RackNerd VPS | RustDesk relay server | Cloud (Los Angeles DC) | 107.175.137.52 | Ubuntu 24.04 |

### Network Segmentation

The AI Box runs on the ASUS guest WiFi, which is isolated from the main LAN by default. It cannot reach devices on 10.0.1.x directly. All cross-network communication goes through Tailscale tunnels, which ride over the internet as encrypted traffic — invisible to the router's guest network isolation rules.

The K8 Plus with the 7900 XTX GPU sits on the main LAN and is accessible via Tailscale from both the main desktop and the AI Box.

### Tailscale Mesh

All interconnected devices run Tailscale and communicate over 100.x.x.x addresses. The tailnet provides:

- Encrypted tunnel between all devices regardless of network segment
- RDP access from K8 Plus to AI Box (guest WiFi → Tailscale → main LAN)
- Ollama API access from AI Box to K8 Plus GPU server
- DNS routing through AdGuard Home on dns01 (active)
- Exit node on dns01 for ad-blocking and privacy on untrusted networks when away from home

**Tailscale Auth:** Authenticated via GitHub (Ohmstyles@github).

**Tailscale ACLs (active):**
- AI Box (100.74.36.8) can ONLY reach K8 Plus on port 11434 (Ollama) and dns01 on port 53 (DNS)
- All other devices (dns01, K8 Plus, laptop, phone) have full access to everything

```json
{
  "acls": [
    {
      "action": "accept",
      "src": ["100.74.36.8"],
      "dst": ["100.123.247.112:11434", "100.125.241.20:53"]
    },
    {
      "action": "accept",
      "src": ["100.125.241.20", "100.123.247.112", "100.81.163.128", "100.97.242.89"],
      "dst": ["*:*"]
    }
  ]
}
```

**Tailscale DNS:** dns01 (100.125.241.20) set as tailnet nameserver with Override local DNS enabled. All tailnet devices route DNS through AdGuard Home automatically.

**Exit Node & Subnet Route:** dns01 approved as exit node and advertises 10.0.1.0/24 subnet route (approved in admin console). This allows remote devices using the exit node to reach LAN devices (Start9, router, etc.). Toggle exit node on from phone or laptop when on untrusted networks (coffee shop WiFi, client sites) to tunnel all traffic through home and get ad blocking + LAN access remotely.

---

## DNS Infrastructure

### Active Configuration (dns01 — AdGuard Home)

**Router DNS:** ASUS WAN DNS set to 10.0.1.201 (primary) with 9.9.9.9 (fallback). LAN DHCP hands out 10.0.1.201 as DNS with 9.9.9.9 fallback. If dns01 goes down, devices fall back to Quad9 directly (no ad blocking, but internet stays up).

**Tailnet DNS:** 100.125.241.20 set as tailnet nameserver with Override local DNS. All Tailscale devices use AdGuard automatically regardless of network.

**Upstream DNS (DoH — stealth priority):**
```
https://dns.quad9.net/dns-query
https://cloudflare-dns.com/dns-query
https://dns.google/dns-query
https://dns.adguard-dns.com/dns-query
```

**Fallback DNS (DoT — different protocol path):**
```
tls://one.one.one.one
tls://dns.quad9.net
tls://dns.google
```

**Bootstrap DNS (plain IP — startup only):**
```
9.9.9.9
1.1.1.1
8.8.8.8
```

**Settings:**
- Parallel requests: Enabled (race all upstreams, use fastest)
- Rate limit: 0 (unlimited for local network)
- Private reverse DNS: Enabled (router at 10.0.1.1 for device names)

**AdGuard DNS Rewrites (Filters → DNS rewrites):**
StartOS `.local` addresses don't resolve through normal DNS — they use mDNS which Tailscale's Override local DNS intercepts. These rewrites allow `.local` addresses to resolve through AdGuard for all tailnet devices.

| Domain | Answer | Service |
|---|---|---|
| potent-hubcaps.local | 10.0.1.225 | StartOS Dashboard |
| ezu65ijzuy3jlw4xc5cpizf6qvnbsa4wtdegwdjsxpjo32c2vsdpwiqd.local | 10.0.1.225 | Mempool |

*Add remaining service `.local` addresses as needed — all point to 10.0.1.225*

---

## Website — barnstormit.com

### Stack
- **Framework:** Next.js 16.2.1 + Tailwind CSS
- **Hosting:** Vercel (Hobby plan, free) — auto-deploys on git push
- **Domain:** barnstormit.com (Porkbun DNS)
- **Repo:** github.com/barnstormit/barnstormit.com (master branch)
- **Design Tool:** Google Stitch for UI mockups → Claude Code for implementation
- **Dev Environment:** AI Box via RDP, Claude Code (Opus 4.6, Max plan, 1M context)

### Development Workflow
```
1. RDP into AI Box from K8 Plus (100.74.36.8)
2. PowerShell window 1: cd ~\Projects\barnstormit.com && npm run dev (runs on port 3001 — 3000 used by Open WebUI)
3. PowerShell window 2: cd ~\Projects\barnstormit.com && claude
4. Browser: localhost:3001 (AI Box) or http://100.74.36.8:3001 (K8 Plus over Tailscale)
5. Build with Claude Code, check browser, iterate
6. git add . && git commit -m "description" (local save)
7. git push (deploys to barnstormit.com via Vercel in ~30 seconds)
```

### Configuration Notes
- `next.config.mjs` has `allowedDevOrigins: ["100.74.36.8"]` for Tailscale hot reload
- Open WebUI occupies port 3000, so dev server runs on 3001
- CLAUDE.md in project root contains full design system rules (color palette, typography, component patterns)
- DESIGN.md contains the comprehensive design spec for Stitch and Claude Code reference
- STITCH_PROMPTS.md contains all 17 page-specific prompts organized by build round

### Design System (from CLAUDE.md)
| Token | Hex | Role |
|---|---|---|
| Deep Navy | #0D1B2A | Primary background |
| Midnight Slate | #1B2838 | Card backgrounds, elevated surfaces |
| Steel Blue | #1A4A7A | Borders, dividers |
| Vivid Teal | #3A9BD5 | Primary accent — buttons, links, highlights |
| Alpine Gold | #F0A500 | Secondary accent — badges, callouts |
| Snow White | #F7F9FC | Primary text |
| Frost Gray | #8AA0B4 | Muted text |

**Typography:** Space Grotesk (headings), DM Sans (body), DM Mono (labels/monospace)

### Pages — Current Status

| Page | Status | Notes |
|---|---|---|
| Homepage | ✅ Live | Hero (local mountain photo), services cards (5), trust section (headshot + bio), service area zones, contact CTA |
| Services | ✅ Live | Full categorized service list — Hardware, Software, Data, Networking, Business IT, 3D Printing, Training, Web & Digital, AI & Automation |
| Contact | ✅ Live | Working email form via Resend API, phone, email, address, hours |
| Remote Support | ✅ Live | RustDesk download links, step-by-step screenshots, copy-to-clipboard server config |
| 3D Printing | ✅ Live | Dedicated page with service cards, how it works, linked from Services page and footer |
| About | ✅ Live | Full bio, career timeline with photos (Buffalo, Colorado, Summit County, Barnstorm launch), credentials |
| Pricing | ✅ Live | Rates, zone table, payment methods |
| Blog | ✅ Live | Post index with category filters, individual post pages, markdown-based, 3 placeholder posts |
| Service Area | Planned | Expanded zone detail with map |
| Vacation Tech Help | Planned | STR niche landing page |

### SEO & Search Engine Setup

| Platform | Status | Notes |
|---|---|---|
| On-site SEO | ✅ Done | Meta tags, OG tags, canonical URLs, sitemap.xml, robots.txt, LocalBusiness JSON-LD schema on all pages |
| Google Search Console | ✅ Verified | Sitemap submitted at barnstormit.com/sitemap.xml |
| Google Business Profile | Needed | business.google.com — #1 local SEO priority, gets into map pack |
| Bing Webmaster Tools | Needed | bing.com/webmasters — feeds Bing, Copilot, ChatGPT search |
| Apple Business Connect | Needed | businessconnect.apple.com — Apple Maps and Siri |
| Yelp | Needed | Claim listing |
| Nextdoor Business | Needed | nextdoor.com/create-business — huge for mountain communities |
| Facebook Business Page | Needed | Link to website |
| LinkedIn Company Page | Needed | For business IT clients |
| Chamber of Commerce | Needed | Park County and Summit County directories |

### Email Form (Resend)
- **Provider:** Resend (resend.com)
- **Account:** resend@dev.barnstormit.com
- **Domain:** barnstormit.com (verified, DNS records in Porkbun)
- **Custom Return Path:** send.barnstormit.com
- **From address:** noreply@barnstormit.com
- **Delivers to:** jeff@barnstormit.com
- **API key:** Stored as `RESEND_API_KEY` environment variable in Vercel + `.env.local` on AI Box
- **API route:** app/api/contact/route.js

### Git History (as of April 3, 2026)
```
67a8c51 Initial commit from Create Next App
69ae7e0 Homepage layout complete - hero, services cards, trust section with headshot
b24805d Service area zone cards with correct pricing and alignment
[CTA section, footer links, hero background, OG meta tags, remote support page,
 contact page with Resend, services page, 3D printing page, full SEO — additional commits]
```

---

## RustDesk — Self-Hosted Remote Support Server

### VPS Details
- **Provider:** RackNerd
- **IP:** 107.175.137.52
- **OS:** Ubuntu 24.04
- **Location:** Los Angeles datacenter
- **SSH:** `ssh root@107.175.137.52`

### Architecture
- **hbbs** — ID/rendezvous server (matchmaking between client and technician)
- **hbbr** — Relay server (traffic relay when direct P2P connection fails)
- Both run as Docker containers with `--net=host`

### Ports

| Port | Protocol | Purpose |
|---|---|---|
| 21115 | TCP | hbbs — NAT type test |
| 21116 | TCP+UDP | hbbs — ID server + hole punching |
| 21117 | TCP | hbbr — relay server |
| 21118 | TCP | hbbs — websocket (optional) |
| 21119 | TCP | hbbr — websocket (optional) |

### Docker Commands
```bash
# Data directory
/opt/rustdesk

# Run hbbs (ID server)
docker run -d \
  --name hbbs \
  --net=host \
  -v /opt/rustdesk:/root \
  --restart=unless-stopped \
  rustdesk/rustdesk-server:latest hbbs

# Run hbbr (relay server)
docker run -d \
  --name hbbr \
  --net=host \
  -v /opt/rustdesk:/root \
  --restart=unless-stopped \
  rustdesk/rustdesk-server:latest hbbr
```

### Public Key
```
znmg4BbrRHz2X20rKw0vqNI5AVv9Dpwy8Lh6KJBNXzw=
```
Located at `/opt/rustdesk/id_ed25519.pub` on the VPS.

### Client Configuration (RustDesk v1.4.6)
In RustDesk client: Settings → Network → ID/Relay Server

| Field | Value |
|---|---|
| ID Server | 107.175.137.52 |
| Relay Server | 107.175.137.52 |
| Key | znmg4BbrRHz2X20rKw0vqNI5AVv9Dpwy8Lh6KJBNXzw= |

**Tested:** Connection verified between AI Box (guest WiFi) and laptop (home WiFi) — server relays correctly across networks. This is the same flow clients will use.

**Server version:** Free OSS (not Pro). Custom branded client not available — clients configure manually or follow instructions on website.

### Client Onboarding (for website Remote Support page)
1. Download RustDesk from rustdesk.com
2. Open Settings → Network → ID/Relay Server
3. Enter server IP and key (above)
4. Call (719) 838-0435 and share the ID shown on screen

### Planned
- DNS: `remote.barnstormit.com` → A record pointing to 107.175.137.52 (Porkbun)
- Custom branded RustDesk client if upgrading to Pro later
- Download links on barnstormit.com/remote-support page

---

## Start9 — GMKtec G3 Plus (StartOS)

### Hardware & Network
- **Device:** GMKtec G3 Plus
- **OS:** StartOS
- **Network:** Main LAN (10.0.1.225)
- **No Tailscale:** StartOS doesn't support Tailscale natively (planned for future StartOS release)

### Access Methods
- **Home (WiFi):** `https://potent-hubcaps.local` — works via mDNS directly
- **Home (Tailscale active):** Same `.local` address — works via AdGuard DNS rewrite
- **Remote (exit node):** Same `.local` address or `https://10.0.1.225` — works via exit node + subnet route
- **Remote (backup):** `.onion` addresses via Tor Browser — fallback if Tailscale/home internet is down

### Installed Services

| Service | Version | Notes |
|---|---|---|
| Bitcoin Knots | 29.3.0 | Full node |
| electrs | 0.11.1 | Electrum server |
| Ghost | 5.130.5 | Blog/CMS |
| Mempool | 3.2.1~3 | Block explorer |
| Nextcloud | 31.0.13~1 | File server |

---

## AI Box — NUCbox G3 Plus (Docker Host)

### Connection
- **Network:** ASUS guest WiFi (isolated from main LAN)
- **Access:** RDP over Tailscale from K8 Plus using 100.74.36.8
- **RDP Port:** 3389 (standard)
- **RDP Auth:** Windows local account with password (not PIN)
- **ACL Restriction:** Can only reach K8 Plus (Ollama, port 11434) and dns01 (DNS, port 53) — all other tailnet access blocked

### Docker Environment
- **Docker Desktop** with WSL 2 backend (Ubuntu)
- **WSL User:** open_claw

### Running Containers

| Container | Image | Port | Purpose | Status |
|---|---|---|---|---|
| Portainer | portainer/portainer-ce:latest | 9000 | Docker management UI | Running |
| Open WebUI | ghcr.io/open-webui/open-webui:main | 3000 | Chat interface for LLMs | Running |
| n8n | docker.n8n.io/n8nio/n8n | 5678 | Workflow automation | Running |
| Proton Bridge | shenxn/protonmail-bridge | 1025 (SMTP), 1143 (IMAP) | Email relay for automation | Running |

### Claude Code (Installed)
- **Path:** `C:\Users\Open Claw\.local\bin\claude.exe`
- **PowerShell alias:** Configured in `C:\Users\Open Claw\Documents\WindowsPowerShell\Microsoft.PowerShell_profile.ps1` (workaround for space in username)
- **Model:** Opus 4.6 (Claude Max plan, 1M context)
- **Auth:** Claude subscription (not API key)
- **Git:** Authenticated via GitHub CLI (`gh auth login`, HTTPS protocol)
- **Skills installed:** Anthropic frontend-design, Vercel web-design-guidelines, ui-ux-pro-max

### Thunderbird Email Client
- **IMAP:** 127.0.0.1:1143, STARTTLS, Bridge-generated credentials
- **SMTP:** 127.0.0.1:1025, Security: None (localhost-only, safe — Bridge encrypts upstream)
- **Send-from identities:** jeff@, billing@, info@ barnstormit.com
- **Folder routing:** Proton server-side filters

### Local Access URLs

| Service | URL |
|---|---|
| Portainer | http://localhost:9000 |
| Open WebUI | http://localhost:3000 |
| n8n | http://localhost:5678 |
| Website Dev | http://localhost:3001 |

---

## K8 Plus — Daily Driver + GPU Inference Server

### Hardware
- **CPU:** AMD (K8 Plus mini PC)
- **GPU:** AMD Radeon RX 7900 XTX (eGPU via OCuLink)
- **Connection:** Main LAN

### Ollama Configuration
- **Install:** Native Windows (not Docker) — simplifies GPU passthrough for AMD
- **Version:** 0.18.2
- **Host:** 0.0.0.0 (listens on all interfaces)
  - Set via: `[System.Environment]::SetEnvironmentVariable("OLLAMA_HOST", "0.0.0.0", "Machine")`
- **Tailscale IP:** 100.123.247.112
- **API Endpoint:** http://100.123.247.112:11434
- **Auto-start:** Startup shortcut in `$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\Ollama.lnk`

### Installed Models

| Model | Size | Use Case |
|---|---|---|
| llama3.2:3b | 2.0 GB | Fast general tasks, testing |
| deepseek-r1:8b | 5.2 GB | Reasoning, code |

### Gaming Coexistence
Ollama sits idle in the system tray when not in use, consuming no VRAM. Models load into VRAM on request and auto-unload after ~5 minutes of inactivity. For guaranteed clean VRAM before gaming: right-click Ollama tray icon → Quit. Reopen from Start menu after gaming.

---

## Raspberry Pi 4 ("dns01") — DNS & Exit Node

### Hardware
- **Hostname:** dns01
- **Storage:** 64GB high-endurance microSD
- **Network:** Main LAN, 10.0.1.201 via DHCP reservation (MAC address bound in ASUS router)
- **SSH Auth:** Public key (ed25519) + password fallback
- **SSH User:** unspoiled2621
- **SSH Access:** `ssh unspoiled2621@dns01.local` or `ssh unspoiled2621@10.0.1.201`

### Services
- **AdGuard Home:** v0.107.73 — web UI at http://10.0.1.201 (port 80), DNS on port 53
- **Tailscale:** v1.96.2 — IP 100.125.241.20, key expiry disabled, exit node approved, subnet route 10.0.1.0/24 advertised
- **IP Forwarding:** Enabled (required for exit node)
- **UDP GRO:** Optimized via /etc/networkd-dispatcher/routable.d/50-tailscale

### Tailscale Command (current)
```
sudo tailscale up --advertise-exit-node --advertise-routes=10.0.1.0/24
```

---

## Email Infrastructure (Reference)

Full details in Email_Infrastructure.md project file. Summary:

| Layer | Provider |
|---|---|
| Domain | barnstormit.com (Porkbun) |
| Mail Host | Proton Mail (Unlimited) |
| Aliases | SimpleLogin (Lifetime) |

**Root mailboxes:** jeff@, billing@, info@ + catch-all

**Subdomains (SimpleLogin):**
- fin.barnstormit.com — financial services
- ops.barnstormit.com — business operations
- dev.barnstormit.com — development/AI tools
- misc.barnstormit.com — throwaway signups (catch-all)
- labs.barnstormit.com — Microsoft 365 sandbox (planned)

---

## Security Architecture

### Network Isolation
- AI Box on guest WiFi cannot reach main LAN (10.0.1.x)
- All cross-network communication via Tailscale encrypted tunnels
- Tailscale ACLs restrict AI Box to K8 Plus port 11434 (Ollama) and dns01 port 53 (DNS) only
- Proton Bridge bound to localhost only (127.0.0.1)
- RustDesk VPS is external — clients connect directly to VPS, not to home network

### DNS Privacy
- All DNS encrypted (DoH primary, DoT fallback)
- ISP cannot see DNS queries (DoH on port 443 = indistinguishable from web traffic)
- AdGuard Home provides ad/tracker blocking network-wide
- Tailnet DNS override ensures all devices (including guest network) use AdGuard Home

### Credential Separation
- Proton Bridge credentials ≠ Proton account credentials
- Each service uses dedicated SimpleLogin alias (compromise one, disable one)
- No email credentials stored on AI Box — Proton Bridge handles auth
- RDP uses Windows local account password, not PIN
- GitHub authenticated via GH CLI with HTTPS (barnstormit account, separate from personal)

---

## Quick Reference — All Services

| Service | Device | URL / Address | Port |
|---|---|---|---|
| Router Admin | ASUS ZenWiFi | http://10.0.1.1 | 80 |
| Portainer | AI Box | http://localhost:9000 | 9000 |
| Open WebUI | AI Box | http://localhost:3000 | 3000 |
| n8n | AI Box | http://localhost:5678 | 5678 |
| Website Dev | AI Box | http://localhost:3001 | 3001 |
| Proton Bridge SMTP | AI Box | localhost | 1025 |
| Proton Bridge IMAP | AI Box | localhost | 1143 |
| Ollama API | K8 Plus | http://100.123.247.112:11434 | 11434 |
| AdGuard Home | dns01 (Pi 4) | http://10.0.1.201 | 80 (web) / 53 (DNS) |
| StartOS Dashboard | Start9 (G3 Plus) | https://potent-hubcaps.local | 443 |
| RustDesk hbbs | RackNerd VPS | 107.175.137.52 | 21116 |
| RustDesk hbbr | RackNerd VPS | 107.175.137.52 | 21117 |
| Website (prod) | Vercel | https://barnstormit.com | 443 |
| GitHub Repo | Cloud | github.com/barnstormit/barnstormit.com | — |
| Tailscale Admin | Cloud | https://login.tailscale.com/admin | — |

---

## Maintenance Notes

### Docker Updates
In Portainer: Images → Pull latest for each image. Then recreate the container from the new image. Or via CLI:
```
docker pull <image>
docker stop <container>
docker rm <container>
# Re-run the original docker run command
```
Data persists in named volumes (portainer_data, open-webui, n8n_data, protonmail).

### Ollama Model Management
```
ollama pull <model>       # Download a model
ollama list               # Show installed models
ollama rm <model>         # Remove a model
ollama show <model>       # Show model details
```

### Website Deployment
```
cd ~\Projects\barnstormit.com
git add . && git commit -m "description"   # Local save
git push                                     # Deploy to Vercel → barnstormit.com
```

### RustDesk VPS SSH
```
ssh root@107.175.137.52
```

### SD Card Health (Pi 4)
High-endurance card mitigates write wear from AdGuard Home logging. Monitor with:
```bash
sudo apt install smartmontools
sudo smartctl -a /dev/mmcblk0
```

---

*Barnstorm Computer Services LLC — Internal Reference*
*Fairplay, CO 80440 — 719-838-0435 — jeff@barnstormit.com*
